import { useState } from 'react';
import { motion } from 'framer-motion';
import { ExternalLink, Calendar, Target, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Section from './Section';

const PortfolioSection = () => {
  const [activeFilter, setActiveFilter] = useState('All');

  const projects = [
    {
      id: 1,
      title: 'SA Innovation Summit — Ecosystem Platform',
      role: 'CEO / Ecosystem Lead',
      summary: 'Scaled a multi-stakeholder platform; increased partner engagement and deal flow across 56 countries.',
      outcome: 'Partner NPS +22; 15,000+ attendees; multi-year sponsorship runway of $2M+',
      date: '2020 - Present',
      tags: ['Innovation', 'Ecosystem', 'Partnerships', 'Events'],
      image: '/api/placeholder/400/250',
      details: {
        context: 'Post-COVID transformation of Africa\'s largest startup event into a comprehensive ecosystem platform.',
        actions: [
          'Scaled event from local to continental reach across 56 countries',
          'Secured $2 million in sponsorship revenue (2022-2025)',
          'Generated PR value over $500k+ with 100M+ digital impressions',
          'Built multi-stakeholder ecosystem connecting startups, investors, and corporates'
        ],
        results: [
          '15,000+ attendees across 56 countries',
          'Partner NPS increased by 22 points',
          '$22+ million in investment deals facilitated (2022-2024)',
          'Established as Africa\'s premier innovation platform'
        ]
      }
    },
    {
      id: 2,
      title: 'TechTribe Accelerator — Virtual Program',
      role: 'Co-Founder / Program Director',
      summary: 'Created Africa\'s first virtual accelerator program supporting 3,500 startups to raise funding.',
      outcome: 'Supported startups to raise $20+ million; mentored 200+ founders',
      date: '2020 - 2024',
      tags: ['Acceleration', 'Startups', 'Mentorship', 'Virtual'],
      image: '/api/placeholder/400/250',
      details: {
        context: 'Co-created one of Africa\'s first virtual accelerator programs during the pandemic.',
        actions: [
          'Designed and launched virtual accelerator curriculum',
          'Mentored 200+ founders through acceleration programs',
          'Built network of investors and corporate partners',
          'Created scalable virtual mentorship platform'
        ],
        results: [
          '3,500 startups supported',
          '$20+ million raised by portfolio companies',
          '200+ founders directly mentored',
          'Established sustainable virtual acceleration model'
        ]
      }
    },
    {
      id: 3,
      title: 'AndAfrica Investment Platform',
      role: 'Executive / Platform Builder',
      summary: 'Built cross-continental investment bridge between Japanese investors and African entrepreneurs.',
      outcome: 'Raised USD 100K seed funding; established SaaS exchange platform',
      date: '2018 - 2019',
      tags: ['Investment', 'Platform', 'International', 'SaaS'],
      image: '/api/placeholder/400/250',
      details: {
        context: 'East-Asia–Africa investment platform connecting Japanese capital with African opportunities.',
        actions: [
          'Raised USD 100K for platform development',
          'Co-founded SaaS online exchange',
          'Built cross-continental investment bridges',
          'Developed deal-making platform infrastructure'
        ],
        results: [
          'USD 100K seed funding secured',
          'Operational SaaS platform launched',
          'Cross-continental investor network established',
          'Foundation for future investment platforms'
        ]
      }
    },
    {
      id: 4,
      title: 'Mining Innovation Project',
      role: 'Senior Strategy & Innovation Consultant',
      summary: 'Delivered strategic innovation project for major mining client, unlocking significant returns.',
      outcome: 'Unlocked 5x forecasted return on workstream through strategic innovation',
      date: '2017',
      tags: ['Innovation', 'Strategy', 'Mining', 'Consulting'],
      image: '/api/placeholder/400/250',
      details: {
        context: 'USD 200K innovation project for major mining client at Research Institute for Innovation & Sustainability.',
        actions: [
          'Delivered comprehensive innovation strategy',
          'Implemented strategic innovation framework',
          'Specialised in management and innovation consulting',
          'Applied chemical engineering expertise to industrial solutions'
        ],
        results: [
          'USD 200K project successfully delivered',
          '5x forecasted return on workstream',
          'Strategic innovation framework implemented',
          'Long-term client relationship established'
        ]
      }
    }
  ];

  const allTags = ['All', ...new Set(projects.flatMap(project => project.tags))];

  const filteredProjects = activeFilter === 'All' 
    ? projects 
    : projects.filter(project => project.tags.includes(activeFilter));

  const [selectedProject, setSelectedProject] = useState(null);

  return (
    <Section id="portfolio" background="default">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold mb-4">
          My <span className="gradient-text">Portfolio</span>
        </h2>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
          Case studies showcasing role, actions, and outcomes across Africa's innovation ecosystem
        </p>

        {/* Filter Tags */}
        <div className="flex flex-wrap justify-center gap-2">
          {allTags.map((tag) => (
            <button
              key={tag}
              onClick={() => setActiveFilter(tag)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                activeFilter === tag
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              }`}
            >
              {tag}
            </button>
          ))}
        </div>
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {filteredProjects.map((project, index) => (
          <motion.div
            key={project.id}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: index * 0.1 }}
            viewport={{ once: true }}
            className="group cursor-pointer"
            onClick={() => setSelectedProject(project)}
          >
            <div className="bg-card border border-border rounded-2xl overflow-hidden hover-lift">
              {/* Project Image Placeholder */}
              <div className="h-48 bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                <div className="text-center">
                  <Target className="w-12 h-12 text-primary mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">Project Visual</p>
                </div>
              </div>

              {/* Content */}
              <div className="p-6 space-y-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-foreground group-hover:text-primary transition-colors">
                      {project.title}
                    </h3>
                    <p className="text-sm text-accent font-medium mt-1">{project.role}</p>
                  </div>
                  <div className="flex items-center text-xs text-muted-foreground">
                    <Calendar className="w-3 h-3 mr-1" />
                    {project.date}
                  </div>
                </div>

                <p className="text-muted-foreground text-sm leading-relaxed">
                  {project.summary}
                </p>

                <div className="flex items-start space-x-2">
                  <TrendingUp className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                  <p className="text-sm text-foreground font-medium">
                    {project.outcome}
                  </p>
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-2 py-1 bg-muted text-muted-foreground text-xs rounded-md"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {/* View Details Button */}
                <div className="pt-2">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="text-primary hover:text-primary/80 p-0 h-auto font-medium"
                  >
                    View Details
                    <ExternalLink className="w-3 h-3 ml-1" />
                  </Button>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Project Detail Modal */}
      {selectedProject && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="bg-card border border-border rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"
          >
            <div className="p-6 space-y-6">
              {/* Header */}
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-2xl font-bold text-foreground mb-2">
                    {selectedProject.title}
                  </h3>
                  <p className="text-accent font-medium">{selectedProject.role}</p>
                  <p className="text-sm text-muted-foreground">{selectedProject.date}</p>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedProject(null)}
                  className="text-muted-foreground hover:text-foreground"
                >
                  ✕
                </Button>
              </div>

              {/* Context */}
              <div>
                <h4 className="text-lg font-semibold text-primary mb-3">Context</h4>
                <p className="text-muted-foreground leading-relaxed">
                  {selectedProject.details.context}
                </p>
              </div>

              {/* Actions */}
              <div>
                <h4 className="text-lg font-semibold text-primary mb-3">Actions Taken</h4>
                <ul className="space-y-2">
                  {selectedProject.details.actions.map((action, index) => (
                    <li key={index} className="flex items-start space-x-2">
                      <span className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0" />
                      <span className="text-muted-foreground">{action}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Results */}
              <div>
                <h4 className="text-lg font-semibold text-primary mb-3">Results & Impact</h4>
                <ul className="space-y-2">
                  {selectedProject.details.results.map((result, index) => (
                    <li key={index} className="flex items-start space-x-2">
                      <TrendingUp className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
                      <span className="text-foreground font-medium">{result}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-2 pt-4 border-t border-border">
                {selectedProject.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-3 py-1 bg-primary/10 text-primary text-sm rounded-full"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </Section>
  );
};

export default PortfolioSection;
